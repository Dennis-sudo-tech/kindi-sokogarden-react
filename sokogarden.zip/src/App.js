import logo from './logo.svg';
import './App.css';
 

import 'bootstrap/dist/css/bootstrap.min.css';

 

import { BrowserRouter as Router, Route, Routes,Link} from "react-router-dom";
import SignUp from './components/SignUp';
import SignIn from './components/SignIn';
import GetProducts from './components/GetProducts';
import AddProducts from './components/AddProducts';
import MpesaPayments from './components/MpesaPayments';
 



function App() {
  return (
    <Router>
    <div className="App">
      <header className="App-header">
       
        <h1>SokoGarden-Buy and sell online</h1>
       
      </header>

      <nav>
        <Link to='SignIn'className='navlinks'>SignIn</Link>
        <Link to='SignUp'className='navlinks'>SignUp</Link>
        <Link to='GetProducts'className='navlinks'>GetProducts</Link>
        <Link to='AddProducts'className='navlinks'>AddProducts</Link>
      </nav>
      
      <Routes>
        <Route path='/signup' element={<SignUp/>}/>
        <Route path='/signin' element={<SignIn/>}/>
        <Route path='/addproducts' element={<AddProducts/>}/>
        <Route path='/' element={<GetProducts/>}/>
        <Route path='/mpesapayment' element={<MpesaPayments/>}/>


      </Routes>
    </div>
    </Router>
  );
}

export default App;

// soko gareden endpoints
// https://dennismutiso.pythonanywhere.com/api/signin
// https://dennismutiso.pythonanywhere.com/api/add_product
// https://dennismutiso.pythonanywhere.com/api/get_products_details
// https://dennismutiso.pythonanywhere.com/api/signup
// https://dennismutiso.pythonanywhere.com/api/mpesa_payment
