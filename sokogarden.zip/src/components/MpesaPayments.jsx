import React from 'react'
import axios from 'axios'
import { useState } from 'react'
import { useLocation } from 'react-router-dom'

const MpesaPayments = () => {
  const[loading,setLoading]=useState("")
  const[message,setMessage]=useState("")
  const[phone,setPhone]=useState("")
  const[error,setError]=useState("")
  const {product}=useLocation().state || {}

  const submit=async(e)=>{
    e.preventDefault()
    setLoading('')

    try{
      const data=new FormData()
      data.append("phone",phone)
      data.append("amount",product.cost)

      const response=await axios.post("https://Lab9.pythonanywhere.com/api/mpesa_payment",data)
      setLoading('')
      setMessage(response.data.message)
    } catch(error){
      setLoading('')
      setError(error.message)
    }
  



  }

 
  
  
  return (
    <div className='row justify-content-center'>
      <h2 className='mt-4'>MpesaPayments-Lipa Na Mpesa</h2>

      <div className='col-md-6 card shadow p-4'>
        <p className='text-info'>Product Name {product.product_name}</p>
        <p className='text-warning'>Product Cost {product.product_cost} </p>

      <form action="" onSubmit={submit}>
        <p className='text-warning'>{loading}</p>
        <p className='text-danger'>{error}</p>
        <p className='text-success'>{message}</p>




        <input type="tel" placeholder='254********' className='form-control'value={phone}
        onChange={(e)=>setPhone(e.target.value)} />

        <br />
        <br />

        <button className='btn btn-dark' type='submit'>Make payments</button>
        
      

      </form>

    
    </div>
    </div>
  )
}

export default MpesaPayments