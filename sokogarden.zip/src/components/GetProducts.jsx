import React from 'react'
import axios from 'axios'
import { useState ,useEffect} from 'react'
import { useNavigate } from 'react-router-dom'

const GetProducts = () => {
  const[loading,setLoading]=useState("")
  const[error,setError]=useState("")
  const[products,setProducts]=useState([])
  const navigate=useNavigate()
  const img_url = "https://www.pythonanywhere.com/user/Lab9/files/home/Lab9/static/images/"
  console.log (img_url)

  // function to fetch products from the api

  const getProducts=async()=>{
    setLoading("Please wait...")

    try{
      const response=await axios.get("https://lab9.pythonanywhere.com/api/get_products_details")
      console.log(response)

      setLoading("")
      setProducts(response.data)

    }

    catch (error) {
      setLoading("")
      setError(error.message)
   

    }
  }

  useEffect(()=>{
    getProducts()

  },[]);

  



  
  return (
    <div className='row container-fluid'> 
        {/* <h1 className='bg-info'>Welcome to GetProducts page </h1> */}

        <h2 className='mt-4'>Available Products</h2>

        <p className='text-warning'>{loading}</p>
        <p className='text-danger'>{error}</p>


        {products.map((product)=>(
          <div className='col-md-3 justify-content-center mb-4'>
            <div className='card shadow'>

              <img src={img_url+product.product_photo } className='product_img mt-2' alt="" />

              <div className='card-body'> 
                <h4 className='mt-4'>{product.product_name}</h4>
                <p className='text-muted'>{product.product_description}</p>
                <b className='text-warning'>{product.product_cost}</b>
                <button className='btn btn-dark mt-2 w-100' onClick={(e)=>navigate("/mpesapayment",{state:{product}})}>purchase now</button>

              </div>

            </div>

          </div>
        ))}
        

    </div>
  )
}

export default GetProducts