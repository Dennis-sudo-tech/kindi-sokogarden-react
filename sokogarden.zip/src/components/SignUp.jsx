import React from 'react'
import { Link } from 'react-router-dom'
import { useState } from"react";
import axios from "axios"

const SignUp = () => {
  const[username,SetUsername]=useState('')
  const[email,SetEmail]=useState('')
  const[phone,SetPhone]=useState('')
  const[password,SetPassword]=useState('')
  const[Loading,SetLoading]=useState('')
  const[Success,SetSuccess]=useState('')
  const[Error,SetError]=useState('')

  const submit=async(e)=>{
    
    e.preventDefault()
    SetLoading("Please wait as we upload your data")
  

  try{
    const data=new FormData()
    data.append("username",username)
    data.append("email",email)
    data.append("phone",phone)
    data.append("password",password)

    const response= await axios.post('https://modcom2.pythonanywhere.com/api/signup',data)

    SetLoading('')
    SetSuccess(response.data.message)




  }catch(error){
    SetLoading('')
    SetError(error.message)

  }
  } 
  return (
    <div className='row justify-content-center mt-4'>

      <div className='col-md-6 p-4 card card shadow'>

     
        
        
        {/* <h1>Welcome to SignUp page</h1> */}

        <h2>Sign Up</h2>

        

        <form action="" onSubmit={submit}>
          
        <p className='text-warning'>{Loading}</p>
        <p className='text-success'>{Success}</p>
        <p className='text-error'>{Error}</p>
        
          <input type="text" placeholder='username' className='form-control' required onChange={(e)=>SetUsername(e.target.value)} value={username}/><br /><br />
        
          
          <input type="email" placeholder='email' className='form-control' required onChange={(e)=>SetEmail(e.target.value)} value={email}/><br /><br />
          
          
          <input type="tel" placeholder='phone' className='form-control' required onChange={(e)=>SetPhone(e.target.value)} value={phone}/><br /><br />
          
          
          <input type="password" placeholder='password' className='form-control' required onChange={(e)=>SetPassword(e.target.value)} value={password}/><br /><br />
          
          
          <button className='btn btn-primary'>
      Sign Up

    </button>
        </form>
    
    <form action="">
    <p>Already have an account?  <Link to='Signin'>SignIn</Link></p>
    </form>

    </div>
    
    </div>

  
  )
}

export default SignUp