import React from 'react'
import { Link } from 'react-router-dom'
import { useState } from"react";
import axios from "axios"
import { useNavigate } from 'react-router-dom';

const SignIn = () => {
  
    
    const[email,SetEmail]=useState('')
    const[password,SetPassword]=useState('')
    const[Loading,SetLoading]=useState('')
    const[Success,SetSuccess]=useState('')
    const[error,SetError]=useState('')
    const navigate=useNavigate()
  
    const submit=async(e)=>{
      
      e.preventDefault()
      SetLoading("Please wait as we log you in")
    
  
    try{
      const data=new FormData()
      
      data.append("email",email)
    
      data.append("password",password)
  
      const response= await axios.post('https://modcom2.pythonanywhere.com/api/signin',data)
      console.log('response')
  
      SetLoading('')
      SetSuccess(response.data.message)

      if(response.data.user){
        navigate('/')
      }

      else{
        SetEmail(response.data.message)
      }
  
  
  
  
    }catch(error){
      SetLoading('')
      SetError(error.message)
  
    }
    } 
  
  return (
    <div className='row justify-content-center mt-4 '>
      <div className='col-md-6 p-4 card card shadow'>
        {/* <h1>Welcome to SignIn page</h1> */}

        <h2>Sign In</h2>

        <form action="" onSubmit={submit}>

        <p className='text-warning'>{Loading}</p>
        <p className='text-success'>{Success}</p>
        <p className='text-error'>{Error}</p>
        

          <input type="Email" placeholder='Enter email' className='form-control' required onChange={(e)=>SetEmail(e.target.value)} value={email}/><br /><br />
          <input type="password" placeholder='Enter password' className='form-control' required onChange={(e)=>SetPassword(e.target.value)} value={password} /><br /><br />

          <button className='btn btn-primary'>
          SignIn
          
          </button>

          
        </form>

       
        <form action="">
          <p>Don't have an account?</p> <p><Link to='SignUp'>SignUp</Link></p>
        </form>
        



    </div>
    </div>
  )
}


export default SignIn